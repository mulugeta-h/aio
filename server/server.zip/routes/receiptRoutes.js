// server/routes/reciptsRoutes.js
const express = require("express");
const router = express.Router();
const { getReciptPool, getLibaioPool } = require("../config/db");
const userAuth = require("../middleware/userAuth");

// =====================================================
// AUTH MIDDLEWARE
// =====================================================
router.use(userAuth);

// =====================================================
// GET TRANSACTIONS BY ACCOUNT NUMBER AND DATE
// =====================================================
router.get("/transactions", async (req, res) => {
  try {
    const { accountNumber,date } = req.query;
    const  downloadedBy =req.user.username;
    const today = new Date();

    console.log("Receipt:", accountNumber, date, downloadedBy);

    if (!accountNumber || !date || !downloadedBy) {
      return res.status(400).json({
        success: false,
        message: "accountNumber, date, downloadedBy required"
      });
    }

    const receiptPool = await getReciptPool();
    const libaioPool = await getLibaioPool(); // 🔥 IMPORTANT

    // Step 1: get transactions
    const txQuery = `
      SELECT 
        t."accountId",
        t."AccountNumber",
        t."AccountHolderName",
        t."CreditedAccountNumber",
        t."referenceId",
        t."amount",
        t."requestedExecutionDate",
        t."paymentType",
        t."paymentScheme",
        t."bankId",
        t."status"
      FROM public."Transaction" t
      WHERE t."AccountNumber" = $1
        AND t."requestedExecutionDate"::date = $2
      ORDER BY t."requestedExecutionDate" DESC
    `;

    const txResult = await receiptPool.query(txQuery, [
      accountNumber,
      date
    ]);

    const transactions = txResult.rows;

    // Step 2: get history (FROM LIBAIO DB)
    const refIds = transactions
      .map(t => t.referenceId)
      .filter(Boolean);

    let historyMap = {};

    if (refIds.length > 0) {
      const historyQuery = `
        SELECT reference_id
        FROM public.receipt_history
        WHERE reference_id = ANY($1)
          AND downloaded_by = $2
          AND downloaded_at::date = $3
      `;

      const historyResult = await libaioPool.query(historyQuery, [
        refIds,
        downloadedBy,
        today
      ]);

      historyResult.rows.forEach(row => {
        historyMap[row.reference_id] = true;
      });
    }

    // Step 3: attach flag
    const finalData = transactions.map(t => {
  const isDownloadedToday = !!historyMap[t.referenceId];

  console.log("Is", t.referenceId, isDownloadedToday,date);

  return {
    ...t,
    isDownloadedToday
  };
});
    
    res.json({
      success: true,
      count: finalData.length,
      data: finalData
    });

  } catch (error) {
    console.error("Error fetching transactions:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch transactions",
      error: error.message
    });
  }
});

// =====================================================
// LOG RECEIPT DOWNLOAD - RECEIVES ALL DATA
// =====================================================
router.post("/log", async (req, res) => {
  try {
    const {
      referenceId,
      accountNumber,
      creditedAccountNumber,
      amount,
      bankId,
      status,
      executionDate,
      downloadedBy,
      userRole,
      downloadedAt
    } = req.body;

    const pool = await getLibaioPool();

    // normalize "today" comparison (date only)
    const checkQuery = `
      SELECT 1
      FROM public.receipt_history
      WHERE reference_id = $1
        AND downloaded_by = $2
        AND DATE(downloaded_at) = DATE($3)
      LIMIT 1
    `;

    const existing = await pool.query(checkQuery, [
      referenceId,
      downloadedBy,
      downloadedAt
    ]);

    if (existing.rowCount > 0) {
      return res.status(409).json({
        success: false,
        message: "Duplicate receipt already logged for today"
      });
    }

    const insertQuery = `
      INSERT INTO public.receipt_history (
        reference_id,
        account_number,
        credited_account_number,
        amount,
        bank_id,
        status,
        execution_date,
        downloaded_by,
        user_role,
        downloaded_at
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
    `;

    await pool.query(insertQuery, [
      referenceId,
      accountNumber,
      creditedAccountNumber,
      amount,
      bankId,
      status,
      executionDate,
      downloadedBy,
      userRole,
      downloadedAt
    ]);

    res.status(200).json({
      success: true,
      message: "Receipt logged successfully"
    });

  } catch (error) {
    console.error("❌ Error logging receipt:", error);

    res.status(500).json({
      success: false,
      message: "Failed to log receipt",
      error: error.message
    });
  }
});
module.exports=router;// server/routes/reciptsRoutes.js
